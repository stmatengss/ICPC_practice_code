////////////////////System Comment////////////////////
////Welcome to Hangzhou Dianzi University Online Judge
////http://acm.hdu.edu.cn
//////////////////////////////////////////////////////
////Username: stmatengss
////Nickname: Stmatengss
////Run ID: 
////Submit time: 2015-08-28 10:20:51
////Compiler: Visual C++
//////////////////////////////////////////////////////
////Problem ID: 1001
////Problem Title: 
////Run result: Accept
////Run time:0MS
////Run memory:1788KB
//////////////////System Comment End//////////////////
#include<iostream>

using namespace std;

long long n;

int main()
{
while(cin>>n)
{
cout<<(n*(n+1)/2)<<endl;
cout<<endl;
}
return 0;
}