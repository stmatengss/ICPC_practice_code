////////////////////System Comment////////////////////
////Welcome to Hangzhou Dianzi University Online Judge
////http://acm.hdu.edu.cn
//////////////////////////////////////////////////////
////Username: stmatengss
////Nickname: Stmatengss
////Run ID: 
////Submit time: 2015-08-28 10:18:16
////Compiler: Visual C++
//////////////////////////////////////////////////////
////Problem ID: 1000
////Problem Title: 
////Run result: Accept
////Run time:0MS
////Run memory:1796KB
//////////////////System Comment End//////////////////
#include<iostream>

using namespace std;

long long a,b;

int main()
{
    while(cin>>a>>b)
    {
cout<<(a+b)<<endl;
    }
}