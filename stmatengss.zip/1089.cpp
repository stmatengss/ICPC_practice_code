////////////////////System Comment////////////////////
////Welcome to Hangzhou Dianzi University Online Judge
////http://acm.hdu.edu.cn
//////////////////////////////////////////////////////
////Username: stmatengss
////Nickname: Stmatengss
////Run ID: 
////Submit time: 2015-10-23 11:18:26
////Compiler: GUN C++
//////////////////////////////////////////////////////
////Problem ID: 1089
////Problem Title: 
////Run result: Accept
////Run time:15MS
////Run memory:1592KB
//////////////////System Comment End//////////////////
#include <iostream>

using namespace std;

typedef long long ll;

int main()
{
    ll a,b;
    while(cin>>a>>b)
    {
        cout<<(a+b)<<endl;
    }
//    cout << "Hello world!" << endl;
    return 0;
}
