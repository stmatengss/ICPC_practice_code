////////////////////System Comment////////////////////
////Welcome to Hangzhou Dianzi University Online Judge
////http://acm.hdu.edu.cn
//////////////////////////////////////////////////////
////Username: stmatengss
////Nickname: Stmatengss
////Run ID: 
////Submit time: 2015-10-21 11:46:07
////Compiler: GUN C++
//////////////////////////////////////////////////////
////Problem ID: 1012
////Problem Title: 
////Run result: Accept
////Run time:0MS
////Run memory:1536KB
//////////////////System Comment End//////////////////
#include <iostream>

using namespace std;

int main()
{
    cout<<"n e"<<endl;
    cout<<"- -----------"<<endl;
    cout<<"0 1"<<endl;
    cout<<"1 2"<<endl;
    cout<<"2 2.5"<<endl;
    cout<<"3 2.666666667"<<endl;
    cout<<"4 2.708333333"<<endl;
    cout<<"5 2.716666667"<<endl;
    cout<<"6 2.718055556"<<endl;
    cout<<"7 2.718253968"<<endl;
    cout<<"8 2.718278770"<<endl;
    cout<<"9 2.718281526"<<endl;

//    cout << "Hello world!" << endl;
    return 0;
}